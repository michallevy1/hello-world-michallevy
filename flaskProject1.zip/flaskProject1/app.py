from flask import Flask, render_template, redirect, url_for, request, session

app = Flask(__name__)
app.secret_key = '123'
@app.route('/')
@app.route('/CV_final.html')
def CV():
    return render_template('CV_final.html')

@app.route('/contact_michal.html')
def Contact_Us():
    return render_template('contact_michal.html')

@app.route('/User_List.html')
def Users():
    return render_template('User_List.html')

@app.route('/assigment8.html')
def assigment8():
    return render_template('assigment8.html',
                           firstName="", lastName="levy",
                           my_hobbies=['Dance', 'Party', 'Friends']
                           )
@app.route('/block_assigment8.html')
def block_assigment8():
    return render_template('block_assigment8.html')

@app.route('/assigment9.html', methods=['GET', 'POST'])
def assigment9():
    user_list = {"Michal": "michal@gmail.com", "Lior": "lior@gmail.com", "Nadav": "nadav@gmail.com", "Tali": "tali@gmail.com", "Oria": "Oria@gmail.com",
                 "Michael": "michael@gmail.com", "Noa": "noa@gmail.com"}
    name = 'member'
    username = ' '
    logged_in = True

    if request.method == 'GET':
        if 'name' in request.args:
            name = request.args['name']

    if request.method == 'POST':
        username = request.form['username']
        session['logged_in'] = True
        session['username'] = username

    return render_template('assigment9.html',
                               request_method=request.method,
                               name = name,
                               user_list = user_list,
                               username = username )

@app.route('/log_out')
def log_out():
    session.pop('username')
    session['logged_in'] = False
    return redirect('/assignment9')

if __name__ == '__main__':
    app.run(debug=True)
