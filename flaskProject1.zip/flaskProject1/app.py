from flask import Flask, render_template, redirect, url_for, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/CV_final.html')
def CV():
    return render_template('CV_final.html')

@app.route('/contact_michal.html')
def Contact_Us():
    return render_template('contact_michal.html')

@app.route('/User_List.html')
def Users():
    return render_template('User_List.html')

@app.route('/assigment8.html')
def assigment8():
    return render_template('assigment8.html',
                           firstName="", lastName="levy",
                           my_hobbies=['Dance', 'Party', 'Friends']
                           )
@app.route('/block_assigment8.html')
def block_assigment8():
    return render_template('block_assigment8.html',
                           friends=['Gal', 'Alma', 'Yuval']
                           )

if __name__ == '__main__':
    app.run(debug=True)
