function bigImg(x) {
  x.style.height = "220px";
  x.style.width = "220px";
}

function normalImg(x) {
  x.style.height = "170px";
  x.style.width = "170px";
}